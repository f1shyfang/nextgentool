NEXTGEN VENTURES - WEBSITE BRAND KIT

Start with NextGen-Ventures-Brand-Guidelines.pdf.

logos/ contains original-derived SVG lockups and symbol variants.
tokens/ contains editable CSS and JSON website tokens.
references/ contains asset sources and the existing design-system record.

This kit describes the website identity as implemented on 24 October 2026.
Clear space, minimum size, writing and accessibility guidance are recommendations.
Font binaries and photographs are not included; source references are recorded.
